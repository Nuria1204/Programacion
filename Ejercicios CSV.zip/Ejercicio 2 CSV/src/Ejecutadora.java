public class Ejecutadora {
    static void main() {
        String ruta= "C:\\Users\\1DAW\\IdeaProjects\\Ejercicio 2 CSV\\src\\datos";
        Leer.Leer(ruta);
    }
}

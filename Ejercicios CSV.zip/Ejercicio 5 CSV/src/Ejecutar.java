import java.util.Scanner;

public class Ejecutar {
    static void main() {
        String ruta = "C:\\Users\\1DAW\\IdeaProjects\\Ejercicio 4 CSV\\src\\datos 2.csv";
        Leer.contarlineas(ruta);
    }
}

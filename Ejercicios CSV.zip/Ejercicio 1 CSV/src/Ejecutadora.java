public class Ejecutadora {
    static void main() {
        String ruta = "C:\\Users\\1DAW\\IdeaProjects\\Ejercicios CSV\\src\\datos.csv";
        String datos= "nombre, edad, ciudad";
        Escritura.escritura(ruta,datos);
    }
}
